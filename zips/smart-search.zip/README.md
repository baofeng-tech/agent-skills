# Smart Search

GitHub-ready release package prepared specifically for agentskill.sh import and refresh.

## Notes

- Intelligent hybrid search combining web and academic sources via AIsa Smart Search endpoint. Best when you need both web and scholarly results. Use when: the user needs web search, research, source discovery, or content extraction.
- This directory keeps one root-level skill per folder so agentskill.sh can scan the repository cleanly.
- The same skill can also be submitted by direct `SKILL.md` URL when needed.
